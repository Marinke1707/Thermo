package eu.arrowhead.core.orchestrator;

import org.springframework.stereotype.Component;

import eu.arrowhead.common.testhelper.StandaloneModeInTests;

@Component
public class StandaloneModeInOrchestratorTests extends StandaloneModeInTests {

}