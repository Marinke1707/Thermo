package eu.arrowhead.core.gateway;

import org.springframework.stereotype.Component;

import eu.arrowhead.common.testhelper.StandaloneModeInTests;

@Component
public class StandaloneModeInGatewayTests extends StandaloneModeInTests  {

}
