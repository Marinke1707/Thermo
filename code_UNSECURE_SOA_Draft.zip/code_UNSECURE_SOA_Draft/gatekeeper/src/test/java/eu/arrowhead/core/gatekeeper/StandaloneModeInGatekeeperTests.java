package eu.arrowhead.core.gatekeeper;

import org.springframework.stereotype.Component;

import eu.arrowhead.common.testhelper.StandaloneModeInTests;

@Component
public class StandaloneModeInGatekeeperTests extends StandaloneModeInTests {

}