package eu.arrowhead.common.dto.internal;

public enum RelayType {
	GATEKEEPER_RELAY, GATEWAY_RELAY, GENERAL_RELAY
}