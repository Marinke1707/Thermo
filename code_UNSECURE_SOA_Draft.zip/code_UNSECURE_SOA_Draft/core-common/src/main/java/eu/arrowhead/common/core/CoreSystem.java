package eu.arrowhead.common.core;

import java.util.Collections;
import java.util.List;

import org.springframework.util.Assert;

import eu.arrowhead.common.CommonConstants;
import eu.arrowhead.common.Defaults;

public enum CoreSystem {
	
	//=================================================================================================
	// define the core system with all service which it provides
	C3_CONSUMER(Defaults.DEFAULT_C3_CONSUMER_PORT, List.of(CoreSystemService.C3_CONSUMER_TEST_SERVICE)),
	C4_PRODUCER(Defaults.DEFAULT_C4_PRODUCER_PORT, List.of(CoreSystemService.C4_PRODUCER_GET_SERVICE, CoreSystemService.C4_PRODUCER_TURN_ON_SERVICE, CoreSystemService.C4_PRODUCER_TURN_OFF_SERVICE)),
	C5_CONSUMER(Defaults.DEFAULT_C5_CONSUMER_PORT, List.of(CoreSystemService.C5_CONSUMER_SENSOR_SERVICE)),
	TEST_PRODUCER(Defaults.DEFAULT_TEST_PRODUCER_PORT, List.of(CoreSystemService.TEST_PRODUCER_GET_SERVICE)),
	TEST_CONSUMER(Defaults.DEFAULT_TEST_CONSUMER_PORT, List.of(CoreSystemService.TEST_CONSUMER_SERVICE)),
	SENSOR_PRODUCER(Defaults.DEFAULT_SENSOR_PRODUCER_PORT, List.of(CoreSystemService.SENSOR_PRODUCER_GET_SERVICE, CoreSystemService.SENSOR_PRODUCER_TURN_ON_SERVICE, CoreSystemService.SENSOR_PRODUCER_TURN_OFF_SERVICE)),
	SERVICE_REGISTRY(Defaults.DEFAULT_SERVICE_REGISTRY_PORT, null),
	AUTHORIZATION(Defaults.DEFAULT_AUTHORIZATION_PORT, List.of(CoreSystemService.AUTH_CONTROL_INTRA_SERVICE, CoreSystemService.AUTH_CONTROL_INTER_SERVICE,
															   CoreSystemService.AUTH_TOKEN_GENERATION_SERVICE, CoreSystemService.AUTH_PUBLIC_KEY_SERVICE,
															   CoreSystemService.AUTH_CONTROL_SUBSCRIPTION_SERVICE)),
	ORCHESTRATOR(Defaults.DEFAULT_ORCHESTRATOR_PORT, List.of(CoreSystemService.ORCHESTRATION_SERVICE)), 
	GATEKEEPER(Defaults.DEFAULT_GATEKEEPER_PORT, List.of(CoreSystemService.GATEKEEPER_GLOBAL_SERVICE_DISCOVERY, CoreSystemService.GATEKEEPER_INTER_CLOUD_NEGOTIATION)),
	EVENT_HANDLER(Defaults.DEFAULT_EVENT_HANDLER_PORT, List.of(CoreSystemService.EVENT_PUBLISH_SERVICE, CoreSystemService.EVENT_SUBSCRIBE_SERVICE
			, CoreSystemService.EVENT_UNSUBSCRIBE_SERVICE,  CoreSystemService.EVENT_PUBLISH_AUTH_UPDATE_SERVICE)),
	GATEWAY(Defaults.DEFAULT_GATEWAY_PORT, List.of(CoreSystemService.GATEWAY_PUBLIC_KEY_SERVICE, CoreSystemService.GATEWAY_PROVIDER_SERVICE,CoreSystemService.GATEWAY_CONSUMER_SERVICE)),
	CHOREOGRAPHER(Defaults.DEFAULT_CHOREOGRAPHER_PORT, List.of()), // TODO: add services
	CERTIFICATE_AUTHORITY(Defaults.DEFAULT_CERTIFICATE_AUTHORITY_PORT, List.of()); // TODO: add services		
	
	
	//=================================================================================================
	// members
	
	private final int defaultPort;
	private final List<CoreSystemService> services;
	
	//=================================================================================================
	// methods
	
	//-------------------------------------------------------------------------------------------------
	public int getDefaultPort() { return defaultPort; }
	public List<CoreSystemService> getServices() { return services; }
	
	//=================================================================================================
	// assistant methods

	//-------------------------------------------------------------------------------------------------
	private CoreSystem(final int defaultPort, final List<CoreSystemService> services) {
		Assert.isTrue(defaultPort > CommonConstants.SYSTEM_PORT_RANGE_MIN && defaultPort < CommonConstants.SYSTEM_PORT_RANGE_MAX, "Default port is invalid.");
		this.services = services != null ? Collections.unmodifiableList(services) : List.of();
		this.defaultPort = defaultPort;
	}
}
