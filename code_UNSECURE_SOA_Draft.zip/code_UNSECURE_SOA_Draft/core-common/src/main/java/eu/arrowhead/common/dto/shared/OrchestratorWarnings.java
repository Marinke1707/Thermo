package eu.arrowhead.common.dto.shared;

public enum OrchestratorWarnings {
	FROM_OTHER_CLOUD, TTL_EXPIRING, TTL_EXPIRED, TTL_UNKNOWN
}