package eu.arrowhead.common.dto.shared;

public enum ServiceSecurityType {
	NOT_SECURE, CERTIFICATE, TOKEN
}