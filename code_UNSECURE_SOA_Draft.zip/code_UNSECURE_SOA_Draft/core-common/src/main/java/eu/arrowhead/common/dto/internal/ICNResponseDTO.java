package eu.arrowhead.common.dto.internal;

import java.io.Serializable;

import eu.arrowhead.common.dto.shared.OrchestrationResponseDTO;

public class ICNResponseDTO extends OrchestrationResponseDTO implements Serializable {

	//=================================================================================================
	// members

	private static final long serialVersionUID = 419607094931834994L;
}