package eu.arrowhead.core.choreographer;

import eu.arrowhead.common.ApplicationInitListener;
import org.springframework.stereotype.Component;

@Component
public class ChoreographerApplicationInitListener extends ApplicationInitListener {
}
