package eu.arrowhead.core.eventhandler.metadatafiltering;

public interface MetadataFilteringAlgorithm {
	//=================================================================================================
	// methods
	
	//-------------------------------------------------------------------------------------------------
	public boolean doFiltering(final MetadataFilteringParameters params);
}
