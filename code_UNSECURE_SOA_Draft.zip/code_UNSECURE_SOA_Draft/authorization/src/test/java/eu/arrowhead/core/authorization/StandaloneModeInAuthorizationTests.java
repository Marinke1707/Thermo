package eu.arrowhead.core.authorization;

import org.springframework.stereotype.Component;

import eu.arrowhead.common.testhelper.StandaloneModeInTests;

@Component
public class StandaloneModeInAuthorizationTests extends StandaloneModeInTests {

}