package eu.arrowhead.mit.soa.utils;

import java.text.DateFormat;
import java.text.SimpleDateFormat;

public class SoaConsumerConstants {
	
	// Outsourcing of the constants, which are needed for the consumer
	
	static final String SECURE_PROTOCOL = "https://";
	static final String INSECURE_PROTOCOL = "http://";
	static final String PORT_COLON = ":";
	static final String GET_REQUEST_METHOD = "GET";
	static final String ACCEPT_REQUEST_PROPERTY_KEYWORD = "Accept";
	static final String ACCEPT_REQUEST_PROPERTY_VALUE = "text/plain";
	static final String PROPERTY_C4_ADDRESS = "c4_address";
	static final String PROPERTY_C4_PATH = "c4_path";
	static final String PROPERTY_C4_PORT = "c4_port";
	static final String PROPERTY_FILE_NAME = "application.properties";
	static final DateFormat SDF = new SimpleDateFormat("[dd.MM.yyyy, HH:mm:ss.SSS]: ");
	
	public static final int MAX_TEMPERATURE = 25; 
	public static final int MIN_TEMPERATURE = 23; 
}
