package eu.arrowhead.mit.soa.utils;

import java.util.Random;

public class SoaConsumerTempGenerator {
	
	// generator for temperature
	// this should be changed to the sensor for the final presentation
	
	double maxValue = 30.0; 
	double minValue = 20.0; 

	public double getTemperature() {
		Random r = new Random();
		double value = (r.nextInt((int)((maxValue - minValue) * 10 + 1)) + minValue * 10) / 10.0; 
	    return value; 
	}
}
