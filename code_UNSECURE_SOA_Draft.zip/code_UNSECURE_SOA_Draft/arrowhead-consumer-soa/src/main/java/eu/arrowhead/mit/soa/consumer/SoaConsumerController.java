package eu.arrowhead.mit.soa.consumer;

import java.io.IOException;
import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import eu.arrowhead.common.CommonConstants;
import eu.arrowhead.common.CoreCommonConstants;
import eu.arrowhead.common.Defaults;
import eu.arrowhead.mit.soa.utils.SoaConsumerConnection;
import eu.arrowhead.mit.soa.utils.SoaConsumerConstants;
import eu.arrowhead.mit.soa.utils.SoaConsumerTempGenerator;
import io.swagger.annotations.Api;

@Api(tags = { CoreCommonConstants.SWAGGER_TAG_ALL })
@CrossOrigin(maxAge = Defaults.CORS_MAX_AGE, allowCredentials = Defaults.CORS_ALLOW_CREDENTIALS, allowedHeaders = {
		HttpHeaders.ORIGIN, HttpHeaders.CONTENT_TYPE, HttpHeaders.ACCEPT, HttpHeaders.AUTHORIZATION })
@RestController
@RequestMapping(CommonConstants.MIT_SOA_C3_CONSUMER_URI)
public class SoaConsumerController {
	
	// services provided by the consumer with logic behind
	
	@Autowired
	private SoaConsumerConnection scc;

	@GetMapping(path = CommonConstants.ECHO_URI)
	public String echoService() {
		return "Got it!";
	}
 
	@RequestMapping(value = CommonConstants.MIT_SOA_C3_CONSUMER_TEST_URI, method = RequestMethod.GET, produces = MediaType.TEXT_PLAIN_VALUE)
	ResponseEntity<String> TestMethod(@RequestParam int runs) throws IOException {
			String[] ret = new String[runs];

			SoaConsumerTempGenerator sctg = new SoaConsumerTempGenerator(); 
			double temperatureValue = 0.0;
			String checkCurrentAirConditionStatus = scc.getStatusAirCondition();
			
			ret[0] = "Check if on or off: " + checkCurrentAirConditionStatus + "\n"; 
		
			for(int i= 1; i<runs; i++) {
				temperatureValue = sctg.getTemperature(); 
				if(temperatureValue > SoaConsumerConstants.MAX_TEMPERATURE && checkCurrentAirConditionStatus.equals("OFF")) {
					// die Variable mit neuem Status üebrschreiben da return "ON" ist. 
					checkCurrentAirConditionStatus = scc.turnAirConditionOn();
					ret[i] =i+". Testrun: It is too hot!! Temperature = " + temperatureValue +", ConditionerStatus: " + checkCurrentAirConditionStatus +"\n"; 
				}
				else if (temperatureValue <= SoaConsumerConstants.MIN_TEMPERATURE && checkCurrentAirConditionStatus.equals("ON")) {
					checkCurrentAirConditionStatus = scc.turnAirConditionOff();
					ret[i] = i+". Testrun: It is too cold!! Temperature = " + temperatureValue +", ConditionerStatus: " + checkCurrentAirConditionStatus+ "\n";
				}
				else {
					ret[i] =i+". Testrun: AirCondition is ok, Temperature = " + temperatureValue +", ConditionerStatus: " + checkCurrentAirConditionStatus +"\n";
				}
			}
			
			

			return new ResponseEntity<String>(Arrays.deepToString(ret), HttpStatus.OK);
	}
}