package eu.arrowhead.mit.sensor.consumer;

import java.io.IOException;
import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import eu.arrowhead.common.CommonConstants;
import eu.arrowhead.common.CoreCommonConstants;
import eu.arrowhead.common.Defaults;
import eu.arrowhead.mit.sensor.reader.SensorReader;
import eu.arrowhead.mit.sensor.utils.ConsumerConnection;
import eu.arrowhead.mit.sensor.utils.ConsumerConstants;
import io.swagger.annotations.Api;

@Api(tags = { CoreCommonConstants.SWAGGER_TAG_ALL })
@CrossOrigin(maxAge = Defaults.CORS_MAX_AGE, allowCredentials = Defaults.CORS_ALLOW_CREDENTIALS, allowedHeaders = {
		HttpHeaders.ORIGIN, HttpHeaders.CONTENT_TYPE, HttpHeaders.ACCEPT, HttpHeaders.AUTHORIZATION })
@RestController
@RequestMapping(CommonConstants.MIT_SENSOR_C5_CONSUMER_URI)
public class ConsumerController {

	@Autowired
	private ConsumerConnection scc;

	@GetMapping(path = CommonConstants.ECHO_URI)
	public String echoService() {
		return "Got it!";
	}

	@RequestMapping(value = CommonConstants.MIT_SENSOR_C5_CONSUMER_TEST_URI, method = RequestMethod.GET, produces = MediaType.TEXT_PLAIN_VALUE)
	ResponseEntity<String> TestMethod(@RequestParam int runs) throws IOException, InterruptedException {
		String[] ret = new String[runs];

		Double temperatureValue = 0.0;
		String checkLedStatus = "Led is off";
		int errorCounter = 0;

		final SensorReader sensorReader = new SensorReader();
		System.out.println("Before connecting");
		sensorReader.connect();

		System.out.println("after connecting");

		ret[0] = "Check einbauen? ";

		for (int i = 1; i < runs; i++) {
			Thread.sleep(1000);
			temperatureValue = sensorReader.getTemperature();
			System.out.println("temperaturvalue " + temperatureValue);
			try {
				if (temperatureValue >= ConsumerConstants.MAX_TEMPERATURE
						&& checkLedStatus.equalsIgnoreCase("Led is off")) {
					checkLedStatus = scc.turnLedOn();
					ret[i] = i + ". Testrun: It is too hot!! Temperature = " + temperatureValue + ", Ledstatus: "
							+ checkLedStatus + "\n";
				} else if (temperatureValue <= ConsumerConstants.MIN_TEMPERATURE
						&& checkLedStatus.equalsIgnoreCase("Led is on")) {
					checkLedStatus = scc.turnLedOff();
					ret[i] = i + ". Testrun: It is too cold!! Temperature = " + temperatureValue + ", Ledstatus: "
							+ checkLedStatus + "\n";
				} else {
					ret[i] = i + ". Testrun: AirCondition is ok, Temperature = " + temperatureValue + ", Ledstatus: "
							+ checkLedStatus + "\n";
				}
			} catch (IOException e) {
				errorCounter++;
				if (errorCounter >= ConsumerConstants.ERROR_THRESHOLD) {
					System.out.println("Too many fails!");
					break;
				}
			}
		}

		scc.turnLedOff();

		return new ResponseEntity<String>(Arrays.deepToString(ret), HttpStatus.OK);
	}
}