package eu.arrowhead.mit.sensor.consumer;

import java.util.Random;

public class ConsumerTempGenerator {
	double maxValue = 30.0; 
	double minValue = 20.0; 

	public double getTemperature() {
		Random r = new Random();
		double value = (r.nextInt((int)((maxValue - minValue) * 10 + 1)) + minValue * 10) / 10.0; 
	    return value; 
	}

}
