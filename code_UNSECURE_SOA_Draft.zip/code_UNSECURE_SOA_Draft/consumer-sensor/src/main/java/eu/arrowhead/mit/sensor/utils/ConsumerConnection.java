package eu.arrowhead.mit.sensor.utils;

import java.util.Properties;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.util.UriComponents;

import eu.arrowhead.common.CommonConstants;
import eu.arrowhead.common.Utilities;
import eu.arrowhead.common.dto.shared.OrchestrationFlags;
import eu.arrowhead.common.dto.shared.OrchestrationFlags.Flag;
import eu.arrowhead.common.dto.shared.OrchestrationFormRequestDTO;
import eu.arrowhead.common.dto.shared.OrchestrationResponseDTO;
import eu.arrowhead.common.dto.shared.ServiceQueryFormDTO;
import eu.arrowhead.common.dto.shared.SystemRequestDTO;
import eu.arrowhead.common.dto.shared.SystemResponseDTO;
import eu.arrowhead.common.http.HttpService;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

@Component
public class ConsumerConnection {
	@Autowired
	private HttpService httpService;

	public Properties getProp() throws IOException {
		Properties prop = new Properties();

		String propFileName = ConsumerConstants.PROPERTY_FILE_NAME;
		InputStream inputStream = getClass().getClassLoader().getResourceAsStream(propFileName);

		if (inputStream != null) {
			prop.load(inputStream);
			return prop;
		} else {
			throw new FileNotFoundException("property file '" + propFileName + "' not found in the classpath");
		}
	}

	public UriComponents createOSUri(final String scheme) throws IOException {
		final String osUriStr = CommonConstants.ORCHESTRATOR_URI + CommonConstants.OP_ORCH_PROCESS; // später dann
																									// dynamisch nach
																									// dem man bei der
																									// SR war
		String osAddress = null;
		int osPort = 0;
		Properties prop = getProp();

		if (prop != null) {
			osAddress = prop.getProperty(CommonConstants.ORCHESTRATOR_ADDRESS);
			osPort = Integer.valueOf(prop.getProperty(CommonConstants.ORCHESTRATOR_PORT));
		}

		return Utilities.createURI(scheme, osAddress, osPort, osUriStr);
	}

	public ResponseEntity<String> getStatus(String scheme, SystemResponseDTO provider, String uri) throws IOException {
		ResponseEntity<String> retTemp = null;
		UriComponents providerUri = Utilities.createURI(scheme, provider.getAddress(), provider.getPort(), uri);
		retTemp = httpService.sendRequest(providerUri, HttpMethod.GET, String.class);
		System.out.println("Method getStatus, retTemp: " + retTemp);
		return retTemp;
	}

	public OrchestrationResponseDTO getProducer(String scheme, Properties prop, String pName) throws IOException {
		UriComponents osUri = createOSUri(scheme);

		// create and configure system request for the requesting system
		SystemRequestDTO sr = new SystemRequestDTO();
		sr.setSystemName(CommonConstants.MIT_SENSOR_C5_SYSTEM_NAME);
		sr.setAddress(prop.getProperty(CommonConstants.SERVER_ADDRESS));
		sr.setPort(Integer.valueOf(prop.getProperty(CommonConstants.SERVER_PORT)));

		// create and configure service form for the requested service
		ServiceQueryFormDTO serviceForm = new ServiceQueryFormDTO.Builder(pName)
				.interfaces(CommonConstants.HTTP_INSECURE_JSON).build();

		// set orchestration flags
		OrchestrationFlags flags = new OrchestrationFlags();
		// use dynamic orchestration with this flag
		flags.put(Flag.OVERRIDE_STORE, true);
		// if more entries are found, return only one
		flags.put(Flag.MATCHMAKING, true);

		// create and configure orchestration request
		OrchestrationFormRequestDTO ofr = new OrchestrationFormRequestDTO.Builder(sr).requestedService(serviceForm)
				.flags(flags).build();

		// get orchestration response
		return new OrchestrationResponseDTO(httpService
				.sendRequest(osUri, HttpMethod.POST, OrchestrationResponseDTO.class, ofr).getBody().getResponse());
	}
	
	public String turnLedOn() throws IOException {
		return useDifferentServices(CommonConstants.SENSOR_PRODUCER_SERVICE_TURN_ON); 
	}

	public String turnLedOff() throws IOException {
		return useDifferentServices(CommonConstants.SENSOR_PRODUCER_SERVICE_TURN_OFF); 
	}
	
//	public String getStatusAirCondition() throws IOException {
//		return useDifferentServices(CommonConstants.MIT_SOA_C4_SERVICE_GET);
//	}
//
//	public String turnAirConditionOn() throws IOException {
//		return useDifferentServices(CommonConstants.MIT_SOA_C4_SERVICE_TURN_ON); 
//	}
//
//	public String turnAirConditionOff() throws IOException {
//		return useDifferentServices(CommonConstants.MIT_SOA_C4_SERVICE_TURN_OFF); 
//	}
	
	private String useDifferentServices(String service) throws IOException {
		String retEntity = "";
		Properties prop = getProp();
		String scheme = CommonConstants.HTTP;
		
		OrchestrationResponseDTO orchestrationResponse = getProducer(scheme, prop,
				service);

		if (!orchestrationResponse.getResponse().isEmpty()) {
			retEntity = getStatus(scheme, orchestrationResponse.getResponse().get(0).getProvider(),
					orchestrationResponse.getResponse().get(0).getServiceUri()).getBody();
		}
		return retEntity;
	}

}