package eu.arrowhead.mit.sensor.utils;

import java.text.DateFormat;
import java.text.SimpleDateFormat;

public class ConsumerConstants {
	static final String SECURE_PROTOCOL = "https://";
	static final String INSECURE_PROTOCOL = "http://";
	static final String PORT_COLON = ":";
	static final String GET_REQUEST_METHOD = "GET";
	static final String ACCEPT_REQUEST_PROPERTY_KEYWORD = "Accept";
	static final String ACCEPT_REQUEST_PROPERTY_VALUE = "text/plain";
	static final String PROPERTY_C4_ADDRESS = "c4_address";
	static final String PROPERTY_C4_PATH = "c4_path";
	static final String PROPERTY_C4_PORT = "c4_port";
	static final String PROPERTY_FILE_NAME = "application.properties";
	static final DateFormat SDF = new SimpleDateFormat("[dd.MM.yyyy, HH:mm:ss.SSS]: ");
	
	public static final double MAX_TEMPERATURE = 27.0; 
	public static final double MIN_TEMPERATURE = 26.0; 
	public static final int ERROR_THRESHOLD = 3; 
}
