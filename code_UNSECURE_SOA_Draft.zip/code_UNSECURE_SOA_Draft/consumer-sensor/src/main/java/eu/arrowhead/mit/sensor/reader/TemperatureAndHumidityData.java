package eu.arrowhead.mit.sensor.reader;

import java.util.StringJoiner;

public class TemperatureAndHumidityData {
    private Double temperature;
    private Double humidity;

    public TemperatureAndHumidityData() {
        super();
    }

    public TemperatureAndHumidityData(Double temperature, Double humidity) {
        super();
        this.temperature = temperature;
        this.humidity = humidity;
    }

    public Double getTemperature() {
        return temperature;
    }

    public void setTemperature(Double temperature) {
        this.temperature = temperature;
    }

    public Double getHumidity() {
        return humidity;
    }

    public void setHumidity(Double humidity) {
        this.humidity = humidity;
    }

//    @Override
//    public String toString() {
//        return new StringJoiner(", ", TemperatureAndHumidityData.class.getSimpleName() + "[", "]")
//                .add("temperature=" + getTemperature())
//                .add("humidity=" + getHumidity())
//                .toString();
//    }



} 