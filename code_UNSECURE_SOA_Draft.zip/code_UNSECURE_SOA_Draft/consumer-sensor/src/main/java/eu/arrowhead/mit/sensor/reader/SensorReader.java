package eu.arrowhead.mit.sensor.reader;

import java.io.IOException;

import org.iot.raspberry.grovepi.GrovePi;
import org.iot.raspberry.grovepi.devices.GroveTemperatureAndHumiditySensor;
import org.iot.raspberry.grovepi.devices.GroveTemperatureAndHumidityValue;
import org.iot.raspberry.grovepi.pi4j.GrovePi4J;

public class SensorReader {
	 private GrovePi grovePi;
	    private GroveTemperatureAndHumiditySensor sensor;

	    public SensorReader() {
	    }

	    public void connect() throws IOException {
	        grovePi = new GrovePi4J();
	        sensor = new GroveTemperatureAndHumiditySensor(grovePi, 4, GroveTemperatureAndHumiditySensor.Type.DHT11);
	        System.out.println("Connection finish");
	    }

	    public TemperatureAndHumidityData read() throws IOException {
	        GroveTemperatureAndHumidityValue value;
	        TemperatureAndHumidityData data = new TemperatureAndHumidityData();

	            value = sensor.get();
	            System.out.println("Degrees: " + value.getTemperature());
	            System.out.println("Humidity: " + value.getHumidity());
	            data.setTemperature(value.getTemperature());
	            data.setHumidity(value.getHumidity());

	        return data;
	    }
	    
	    public Double getTemperature() throws IOException {
	    	GroveTemperatureAndHumidityValue value;
	    	TemperatureAndHumidityData data = new TemperatureAndHumidityData();
	    	
	    	value = sensor.get(); 
	    	
	    	data.setTemperature(value.getTemperature());
	    	
	    	return data.getTemperature(); 
	    }
	    
}
