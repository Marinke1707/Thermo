package eu.arrowhead.mit.led.utils;

import java.io.IOException;

import org.iot.raspberry.grovepi.GrovePi;
import org.iot.raspberry.grovepi.devices.GroveLed;
import org.iot.raspberry.grovepi.pi4j.GrovePi4J;
import org.springframework.stereotype.Component;

@Component
public class LedsControl {

	//	
//	private boolean ledsTest = false; 
//	
//	public LedsControll() {}; 
//	
//	public LedsControll(boolean ledsTest) {
//		this.ledsTest = ledsTest; 
//	}


	public String test() {
		return "test"; 
	}

//	public String turnOn(int pin) throws IOException {
//		GrovePi grovePi = new GrovePi4J(); 
//		GroveLed gl = new GroveLed(grovePi, pin); 
//		gl.set(true); 
//		return "Led is on"; 
//	}
//	
//	public String turnOff(int pin) throws IOException {
//		GrovePi grovePi = new GrovePi4J(); 
//		GroveLed gl = new GroveLed(grovePi, pin); 
//		gl.set(false); 
//		return "Led is off"; 
//	}
	
	public String turnOn() throws IOException {
		GrovePi grovePi = new GrovePi4J(); 
		GroveLed gl = new GroveLed(grovePi, 4); 
		gl.set(true); 
		return "Led is on"; 
	}
	
	public String turnOff() throws IOException {
		GrovePi grovePi = new GrovePi4J(); 
		GroveLed gl = new GroveLed(grovePi, 4); 
		gl.set(false); 
		return "Led is off"; 
	}


	public void closeConnection(GrovePi grovePi) {
		grovePi.close();
	}

//	public static void main(String[] args) throws IOException, InterruptedException {
//
//		final Leds tl = new Leds();
//		
//		GroveLed red = tl.connect(4); 
//		GroveLed green = tl.connect(5); 
//		
//		System.out.println("Turn red on");
//		red.set(true);		
//		Thread.sleep(5000);
//		
//		System.out.println("Turn green on");
//		green.set(true);		
//		Thread.sleep(5000);
//		
//		System.out.println("Turn off both");
//		red.set(false);
//		green.set(false); 
//		Thread.sleep(1000);
//		
//		tl.closeConnection();
//	}
}
