package eu.arrowhead.mit.led.producer;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import eu.arrowhead.common.CommonConstants;
import eu.arrowhead.common.CoreCommonConstants;
import eu.arrowhead.common.Defaults;
import eu.arrowhead.mit.led.utils.LedsControl;
import io.swagger.annotations.Api;

@Api(tags = { CoreCommonConstants.SWAGGER_TAG_ALL })
@CrossOrigin(maxAge = Defaults.CORS_MAX_AGE, allowCredentials = Defaults.CORS_ALLOW_CREDENTIALS, allowedHeaders = {
		HttpHeaders.ORIGIN, HttpHeaders.CONTENT_TYPE, HttpHeaders.ACCEPT, HttpHeaders.AUTHORIZATION })
@RestController
@RequestMapping(CommonConstants.SENSOR_PRODUCER_URI)
public class SensorProducerController {
	
	@Autowired
	private LedsControl lc; 
	
	@GetMapping(path = CommonConstants.ECHO_URI)
	public String echoService() {
		return "Got it!";
	}

	@RequestMapping(value = CommonConstants.SENSOR_PRODUCER_GET_URI, method = RequestMethod.GET, produces = MediaType.TEXT_PLAIN_VALUE)
	ResponseEntity<String> statusLed() {
		return new ResponseEntity<String>(lc.test(), HttpStatus.OK);
	}

//
//	@RequestMapping(value = CommonConstants.SENSOR_PRODUCER_TURN_ON_URI, method = RequestMethod.GET, produces = MediaType.TEXT_PLAIN_VALUE)
//	ResponseEntity<String> turnOnLed(@RequestParam int pin) throws IOException {
//		return new ResponseEntity<String>(lc.turnOn(pin), HttpStatus.OK);
//	}
//	
//	@RequestMapping(value = CommonConstants.SENSOR_PRODUCER_TURN_OFF_URI, method = RequestMethod.GET, produces = MediaType.TEXT_PLAIN_VALUE)
//	ResponseEntity<String> turnOffLed(@RequestParam int pin) throws IOException {
//		return new ResponseEntity<String>(lc.turnOff(pin), HttpStatus.OK);
//	}
	
	@RequestMapping(value = CommonConstants.SENSOR_PRODUCER_TURN_ON_URI, method = RequestMethod.GET, produces = MediaType.TEXT_PLAIN_VALUE)
	ResponseEntity<String> turnOnLed() throws IOException {
		return new ResponseEntity<String>(lc.turnOn(), HttpStatus.OK);
	}
	
	@RequestMapping(value = CommonConstants.SENSOR_PRODUCER_TURN_OFF_URI, method = RequestMethod.GET, produces = MediaType.TEXT_PLAIN_VALUE)
	ResponseEntity<String> turnOffLed() throws IOException {
		return new ResponseEntity<String>(lc.turnOff(), HttpStatus.OK);
	}
	
}