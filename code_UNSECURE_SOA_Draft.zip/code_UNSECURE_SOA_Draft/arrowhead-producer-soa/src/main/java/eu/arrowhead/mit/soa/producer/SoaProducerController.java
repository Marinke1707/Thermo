package eu.arrowhead.mit.soa.producer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import eu.arrowhead.common.CommonConstants;
import eu.arrowhead.common.CoreCommonConstants;
import eu.arrowhead.common.Defaults;
import eu.arrowhead.mit.soa.utils.SoaProducerAirCondition;
import io.swagger.annotations.Api;

@Api(tags = { CoreCommonConstants.SWAGGER_TAG_ALL })
@CrossOrigin(maxAge = Defaults.CORS_MAX_AGE, allowCredentials = Defaults.CORS_ALLOW_CREDENTIALS, allowedHeaders = {
		HttpHeaders.ORIGIN, HttpHeaders.CONTENT_TYPE, HttpHeaders.ACCEPT, HttpHeaders.AUTHORIZATION })
@RestController
@RequestMapping(CommonConstants.MIT_SOA_C4_PRODUCER_URI)
public class SoaProducerController {
	
	// in this class are all services provided by the producer defined
	
	@Autowired
	private SoaProducerAirCondition spac;

	@GetMapping(path = CommonConstants.ECHO_URI)
	public String echoService() {
		return "Got it!";
	}

	// at each method you define the url on which the service is reachable
	@RequestMapping(value = CommonConstants.MIT_SOA_C4_PRODUCER_GET_URI, method = RequestMethod.GET, produces = MediaType.TEXT_PLAIN_VALUE)
	ResponseEntity<String> statusAirCondition() {
		return new ResponseEntity<String>(spac.getAirConditionStatus(), HttpStatus.OK);
	}


	@RequestMapping(value = CommonConstants.MIT_SOA_C4_PRODUCER_TURN_ON_URI, method = RequestMethod.GET, produces = MediaType.TEXT_PLAIN_VALUE)
	ResponseEntity<String> turnAirConditionOnController() {
		return new ResponseEntity<String>(spac.turnAirConditionOn(), HttpStatus.OK);
	}
	
	@RequestMapping(value = CommonConstants.MIT_SOA_C4_PRODUCER_TURN_OFF_URI, method = RequestMethod.GET, produces = MediaType.TEXT_PLAIN_VALUE)
	ResponseEntity<String> turnAirConditionOffController() {
		return new ResponseEntity<String>(spac.turnAirCondtionOff(), HttpStatus.OK);
	}
	
}
