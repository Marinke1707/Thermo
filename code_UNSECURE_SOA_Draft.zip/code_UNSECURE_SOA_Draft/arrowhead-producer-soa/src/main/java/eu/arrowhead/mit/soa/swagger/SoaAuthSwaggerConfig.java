package eu.arrowhead.mit.soa.swagger;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import eu.arrowhead.common.CommonConstants;
import eu.arrowhead.common.swagger.DefaultSwaggerConfig;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@EnableSwagger2
@Configuration
public class SoaAuthSwaggerConfig extends DefaultSwaggerConfig {
	
	// this class is necessary to use Swagger
	
	//=================================================================================================
	// methods

	//-------------------------------------------------------------------------------------------------
	
	public SoaAuthSwaggerConfig() {
		super(CommonConstants.MIT_SOA_SYSTEM_PRODUCER);
	}
	
	//-------------------------------------------------------------------------------------------------
	@Bean
	public Docket customizeSwagger() {
		return configureSwaggerForCoreSystem(this.getClass().getPackageName());
	}
}
