package eu.arrowhead.mit.soa.utils;

import org.springframework.stereotype.Component;

@Component
public class SoaProducerAirCondition {
	
	//At the beginning the aircondition should be off
	private boolean airCondition = false; 
	
	public SoaProducerAirCondition() {}
	
	public SoaProducerAirCondition(boolean airCondition) {
		this.airCondition = airCondition;
	}

	public boolean isAirCondition() {
		return airCondition;
	}

	public void setAirCondition(boolean airCondition) {
		this.airCondition = airCondition;
	}

	public String getAirConditionStatus() {
		boolean condition = isAirCondition(); 
		String status = ""; 
		if (condition== false)
		{ status = "OFF"; 		
		}
		else {
			status = "ON";
		}
		return status;
	}	
	
	public String turnAirConditionOn() {
		setAirCondition(true); 
		return getAirConditionStatus();
	}
	
	public String turnAirCondtionOff() {
		setAirCondition(false); 
		return getAirConditionStatus();
	}
	
	
	
	
}
